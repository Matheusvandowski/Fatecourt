document.addEventListener("DOMContentLoaded", () => {
  const form = document.querySelector("form");
  const email = document.getElementById("email");
  const senha = document.getElementById("senha");
  const confirmarSenha = document.getElementById("confirmarSenha");
  const registro = document.getElementById("registro");
  const telefone = document.getElementById("telefone");
  const esporte1 = document.getElementById("esporte1");
  const esporte2 = document.getElementById("esporte2");
  const esporte3 = document.getElementById("esporte3");

  
  function resetBordas() {
    [email, senha, confirmarSenha, registro, telefone, esporte1, esporte2, esporte3].forEach(el => {
      el.style.borderColor = "black";
    });
  }

  form.addEventListener("submit", (e) => {
    e.preventDefault(); 
    resetBordas();

    let valido = true;

    
    if (!email.value.endsWith("@fatec.sp.gov.br")) {
      email.style.borderColor = "red";
      valido = false;
    }

   
    const senhaValor = senha.value;
    const regexSenha = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@#&*])[A-Za-z\d@#&*]{8,12}$/;
    if (!regexSenha.test(senhaValor)) {
      senha.style.borderColor = "red";
      valido = false;
    }

    
    if (senhaValor !== confirmarSenha.value) {
      confirmarSenha.style.borderColor = "red";
      valido = false;
    }

    
    if (!registro.value.trim()) {
      registro.style.borderColor = "red";
      valido = false;
    }

    
    const telefoneValor = telefone.value.replace(/\D/g, '');
    if (telefoneValor.length < 8) {
      telefone.style.borderColor = "red";
      valido = false;
    }

   
    const esportes = [esporte1.value, esporte2.value, esporte3.value].filter(v => v !== "");
    const esportesUnicos = [...new Set(esportes)];
    if (esportes.length === 0) {
      [esporte1, esporte2, esporte3].forEach(el => el.style.borderColor = "red");
      valido = false;
    }
    if (esportes.length !== esportesUnicos.length) {
      [esporte1, esporte2, esporte3].forEach(el => el.style.borderColor = "red");
      valido = false;
    }

    if (!valido) {
      alert("Alguns campos estão inválidos. Confira os campos em destaque.");
      return;
    }

    // Cadastro com sucesso
    alert("Cadastro realizado com sucesso!");
    form.reset();
  });
});
