
const emailInput = document.querySelector('input[type="email"]');
const senhaInput = document.querySelector('input[type="password"]');

const btnAvancar = document.getElementById("avancar");
const btnCadastrar = document.getElementById("cadastrar");
const forgotPassword = document.querySelector(".forgot-password");

// Validar e-mail institucional
function emailInstitucionalValido(email) {
  return email.endsWith("@fatec.sp.gov.br");
}

// BOTÃO AVANÇAR 
btnAvancar.addEventListener("click", () => {
  const email = emailInput.value.trim();
  const senha = senhaInput.value.trim();

  
  if (email === "" || senha === "") {
    alert("Por favor, preencha o e-mail e a senha.");
    return;
  }

  
  if (!emailInstitucionalValido(email)) {
    alert("E-mail inválido! Utilize seu e-mail institucional (@fatec.sp.gov.br).");
    return;
  }

  // Login fake 
  alert("Login realizado com sucesso! (Simulação)");
  
 
});


// BOTÃO CADASTRAR 
btnCadastrar.addEventListener("click", () => {
  // Redireciona para página de cadastro REAL
  // (Você pode me enviar o código da página se quiser integrar tudo)
  window.location.href = "Fatecamigos-cadastro.html";
});


// ESQUECEU A SENHA 
forgotPassword.addEventListener("click", () => {
  // Redireciona para sua futura página de redefinição
  window.location.href = "Fatecamigos-senha.html";
});
